﻿namespace OLS
{
    partial class FormSettings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblLogo = new System.Windows.Forms.Label();
            this.lblGraphics = new System.Windows.Forms.Label();
            this.lblSound = new System.Windows.Forms.Label();
            this.lblFullscreen = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.cbFsOn = new System.Windows.Forms.CheckBox();
            this.tbVolume = new System.Windows.Forms.TrackBar();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.tbVolume)).BeginInit();
            this.SuspendLayout();
            // 
            // lblLogo
            // 
            this.lblLogo.AutoSize = true;
            this.lblLogo.Font = new System.Drawing.Font("Bahnschrift SemiBold", 36F, System.Drawing.FontStyle.Bold);
            this.lblLogo.Location = new System.Drawing.Point(224, 72);
            this.lblLogo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLogo.Name = "lblLogo";
            this.lblLogo.Size = new System.Drawing.Size(565, 144);
            this.lblLogo.TabIndex = 4;
            this.lblLogo.Text = "OGORODNIKOV LIFE\nSIMULATOR";
            this.lblLogo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblGraphics
            // 
            this.lblGraphics.AutoSize = true;
            this.lblGraphics.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.lblGraphics.Location = new System.Drawing.Point(147, 258);
            this.lblGraphics.Name = "lblGraphics";
            this.lblGraphics.Size = new System.Drawing.Size(90, 25);
            this.lblGraphics.TabIndex = 5;
            this.lblGraphics.Text = "Graphics";
            // 
            // lblSound
            // 
            this.lblSound.AutoSize = true;
            this.lblSound.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.lblSound.Location = new System.Drawing.Point(147, 314);
            this.lblSound.Name = "lblSound";
            this.lblSound.Size = new System.Drawing.Size(79, 25);
            this.lblSound.TabIndex = 6;
            this.lblSound.Text = "Volume";
            // 
            // lblFullscreen
            // 
            this.lblFullscreen.AutoSize = true;
            this.lblFullscreen.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.lblFullscreen.Location = new System.Drawing.Point(147, 370);
            this.lblFullscreen.Name = "lblFullscreen";
            this.lblFullscreen.Size = new System.Drawing.Size(156, 25);
            this.lblFullscreen.TabIndex = 7;
            this.lblFullscreen.Text = "Fullscreen mode";
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.btnClose.Location = new System.Drawing.Point(449, 402);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(111, 36);
            this.btnClose.TabIndex = 8;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // cbFsOn
            // 
            this.cbFsOn.AutoSize = true;
            this.cbFsOn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(254)));
            this.cbFsOn.Location = new System.Drawing.Point(309, 375);
            this.cbFsOn.Name = "cbFsOn";
            this.cbFsOn.Size = new System.Drawing.Size(18, 17);
            this.cbFsOn.TabIndex = 9;
            this.cbFsOn.UseVisualStyleBackColor = true;
            this.cbFsOn.CheckedChanged += new System.EventHandler(this.cbFsOn_CheckedChanged);
            // 
            // tbVolume
            // 
            this.tbVolume.Location = new System.Drawing.Point(309, 313);
            this.tbVolume.Name = "tbVolume";
            this.tbVolume.Size = new System.Drawing.Size(456, 56);
            this.tbVolume.TabIndex = 10;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Ultra",
            "Epic",
            "High",
            "Medium",
            "Low",
            "Very low",
            "Potato"});
            this.comboBox1.Location = new System.Drawing.Point(309, 258);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(189, 24);
            this.comboBox1.TabIndex = 11;
            // 
            // FormSettings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.tbVolume);
            this.Controls.Add(this.cbFsOn);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lblFullscreen);
            this.Controls.Add(this.lblSound);
            this.Controls.Add(this.lblGraphics);
            this.Controls.Add(this.lblLogo);
            this.Name = "FormSettings";
            this.Text = "FormSettings";
            ((System.ComponentModel.ISupportInitialize)(this.tbVolume)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblLogo;
        private System.Windows.Forms.Label lblGraphics;
        private System.Windows.Forms.Label lblSound;
        private System.Windows.Forms.Label lblFullscreen;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.CheckBox cbFsOn;
        private System.Windows.Forms.TrackBar tbVolume;
        private System.Windows.Forms.ComboBox comboBox1;
    }
}