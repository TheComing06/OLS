﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OLS
{
    public partial class Form3 : Form
    {

        private uint jerkedOffCounter = 0;
        private uint timer = 15;
        Timer jerkedOffTimer = new Timer();

        public Form3()
        {
            InitializeComponent();

            
            jerkedOffTimer.Interval = 1000;
            jerkedOffTimer.Tick += jerkedOffTimerAction;

            jerkedOffTimer.Start();

        }

        private void jerkedOffTimerAction(object sender, EventArgs e)
        {
            if (timer == 0) 
            {
                jerkedOffTimer.Stop();
                MessageBox.Show("You didn't survive!", "FUCK!");

                Program.Context.MainForm.Close();
                Program.Context.MainForm = new Form1();
                Program.Context.MainForm.Show();
                this.Close();
            }

            timer_counter.Text = timer.ToString();
            timer--;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void jerk_button_Click(object sender, EventArgs e)
        {
            if (jerkedOffCounter == 99) {
                jerk_button.Enabled = false;
                jerkedOffTimer.Stop();
                MessageBox.Show("You jerked off enough times so you survived the enemy's attack.", "You survived!");
                this.Close();
            
            }

            jerkedOffCounter++;
            label3.Text = jerkedOffCounter.ToString();
            jerked_off_progress.Value = (int)jerkedOffCounter;
        }
    }
}
