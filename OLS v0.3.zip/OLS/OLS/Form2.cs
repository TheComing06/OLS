﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OLS
{
    public partial class Form2 : Form
    {
        int currentGameTime = 0; // В минутах
        int currentAfkTime = 0;
        int currentPhraseTime = 0;
        int timeSpeed = 1000;
        Random rnd = new Random();
        Timer timer = new Timer();
        Timer afkTimer = new Timer();
        Timer phraseTimer = new Timer();

        public Form2()
        {
            InitializeComponent();

            timer.Start();
            afkTimer.Start();
            phraseTimer.Start();

            timer.Interval = timeSpeed;
            timer.Tick += AddTime;

            afkTimer.Interval = timeSpeed;
            afkTimer.Tick += AfkAddTime;
           
            phraseTimer.Interval = timeSpeed;
            phraseTimer.Tick += PhraseAddTime;
        }
        private void PhraseAddTime(object sender, EventArgs e)
        {
            currentPhraseTime++;
            
            if (currentPhraseTime == 5)
            {
                RandomAction();
                currentPhraseTime = 0;
            }
        }

        private void AddTime(object sender, EventArgs e)
        {
            currentGameTime += 1;
            label2.Text = currentGameTime.ToString();

            if (currentGameTime == 60)
            {
                timer.Stop();
                afkTimer.Stop();
                label1.Text = "You win!";
                MessageBox.Show("You survived the night!", "Congratulations", MessageBoxButtons.OK);
            }
        }

        private void RandomAction()
        {
            int rand = rnd.Next(1,9);
            if (rand == 1) label1.Text = "Edik said: Ah, snowflake! What did you say about my niggas last night?";
            else if (rand == 2) label1.Text = "Edik said: Get out'ta here, lil' boy!";
            else if (rand == 3) label1.Text = "Edik said: Ahhhh... Ohhhh";
            else if (rand == 4) label1.Text = "Edik said: Uh-m-m... beautiful ass hole!";
            else if (rand == 5) label1.Text = "Edik said: Taste my FAT COCK!";
            else if (rand == 6) label1.Text = "Edik said: I wanna eat you, my little fat boy!";
            else if (rand == 6) label1.Text = "Edik said: I wanna smack your ass";
            else if (rand == 7) label1.Text = "Edik said: Come with me and I'll cum in you...";
            else if (rand == 8) label1.Text = "Edik said: Fuck you, little snow! Get outta here or I'll break this fucking door and rip your ass!";
            else label1.Text = "Edik said: I'll ride you!";
        }

        private void AfkAddTime(object sender, EventArgs e)
        {
            currentAfkTime += 1;
            label3.Text = currentAfkTime.ToString();
            int ran = rnd.Next(1, 4);

            if (currentAfkTime == 10)
            {
                afkTimer.Stop();
                timer.Stop();
                phraseTimer.Stop();
                label1.Text = "Game Over";
                if (ran == 1) MessageBox.Show("Toni entered your room, until You've been afk\nAnd fucked your ass hole", "Game Over", MessageBoxButtons.OK);
                else if (ran == 2) MessageBox.Show("Edik entered your room, until You've been afk\nAnd put his black cock in your mouth", "Game Over", MessageBoxButtons.OK);
                else if (ran == 3) MessageBox.Show("Gabriel(The stormtrooper) entered your room, until You've been afk\nAnd cummed on your face, you are blessed now", "Game Over", MessageBoxButtons.OK);
                else MessageBox.Show("Minometchisa entered your room, until You've been afk\nAnd blowed up you", "Game Over", MessageBoxButtons.OK);
                Program.Context.MainForm = new Form1();
                Program.Context.MainForm.Show();
                this.Close();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int ran = rnd.Next(1, 3);
            DialogResult act = MessageBox.Show("Here is very dark...\nDo you wanna light there?", "Left Door", MessageBoxButtons.YesNo);

            if (act == DialogResult.Yes)
            {
                if (ran == 1)
                {
                    timer.Stop();
                    currentAfkTime = 0;
                    afkTimer.Stop();
                    phraseTimer.Stop();
                    Form form3 = new Form3();
                    form3.Show();

                    form3.FormClosed += (sndr, ev) => {

                        timer.Start();
                        afkTimer.Start();
                        phraseTimer.Start();                    
                    };


                }
                else
                {
                    currentAfkTime = 0;
                    MessageBox.Show("Here is nothing...\nYou returned back", "Action", MessageBoxButtons.OK);
                    currentAfkTime = 0;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int ran = rnd.Next(1, 3);
            DialogResult act = MessageBox.Show("Here is very dark...\nDo you wanna light there?", "Wardrobe", MessageBoxButtons.YesNo);
            if (act == DialogResult.Yes)
            {
                if (ran == 1)
                {
                    timer.Stop();
                    currentAfkTime = 0;
                    afkTimer.Stop();
                    phraseTimer.Stop();
                    Form form3 = new Form3();
                    form3.Show();

                    form3.FormClosed += (sndr, ev) =>
                    {

                        timer.Start();
                        afkTimer.Start();
                        phraseTimer.Start();
                    };
                }
                else
                {
                    currentAfkTime = 0;
                    MessageBox.Show("Here is nothing...\nYou returned back", "Action", MessageBoxButtons.OK);
                    currentAfkTime = 0;
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int ran = rnd.Next(1, 3);
            DialogResult act = MessageBox.Show("Here is very dark...\nDo you wanna light there?", "Right Door", MessageBoxButtons.YesNo);
            if (act == DialogResult.Yes)
            {
                if (ran == 1)
                {
                    timer.Stop();
                    currentAfkTime = 0;
                    afkTimer.Stop();
                    phraseTimer.Stop();
                    Form form3 = new Form3();
                    form3.Show();

                    form3.FormClosed += (sndr, ev) =>
                    {

                        timer.Start();
                        afkTimer.Start();
                        phraseTimer.Start();
                    };
                }
                else
                {
                    currentAfkTime = 0;
                    MessageBox.Show("Here is nothing...\nYou returned back", "Action", MessageBoxButtons.OK);
                    currentAfkTime = 0;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int ran = rnd.Next(1, 3);
            DialogResult act = MessageBox.Show("Here is very dark...\nDo you wanna light there?", "Under bed", MessageBoxButtons.YesNo);
            if (act == DialogResult.Yes)
            {
                if (ran == 1)
                {
                    timer.Stop();
                    currentAfkTime = 0;
                    afkTimer.Stop();
                    phraseTimer.Stop();
                    Form form3 = new Form3();
                    form3.Show();

                    form3.FormClosed += (sndr, ev) =>
                    {

                        timer.Start();
                        afkTimer.Start();
                        phraseTimer.Start();
                    };
                }
                else
                {
                    currentAfkTime = 0;
                    MessageBox.Show("Here is nothing...\nYou returned back", "Action", MessageBoxButtons.OK);
                    currentAfkTime = 0;
                }
            }
        }
    }
}
