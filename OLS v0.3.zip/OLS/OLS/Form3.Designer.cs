﻿namespace OLS
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.jerk_button = new System.Windows.Forms.Button();
            this.jerked_off_progress = new System.Windows.Forms.ProgressBar();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.timer_counter = new System.Windows.Forms.Label();
            this.timer_label = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bahnschrift SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(25, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(365, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "CLICK THE BUTTON TO SAVE YOUR ASS!";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // jerk_button
            // 
            this.jerk_button.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.jerk_button.Font = new System.Drawing.Font("Bahnschrift", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jerk_button.Location = new System.Drawing.Point(12, 338);
            this.jerk_button.Name = "jerk_button";
            this.jerk_button.Size = new System.Drawing.Size(394, 152);
            this.jerk_button.TabIndex = 1;
            this.jerk_button.Text = "JERKING OFF BUTTON";
            this.jerk_button.UseVisualStyleBackColor = true;
            this.jerk_button.Click += new System.EventHandler(this.jerk_button_Click);
            // 
            // jerked_off_progress
            // 
            this.jerked_off_progress.Location = new System.Drawing.Point(12, 301);
            this.jerked_off_progress.Name = "jerked_off_progress";
            this.jerked_off_progress.Size = new System.Drawing.Size(394, 23);
            this.jerked_off_progress.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 282);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 16);
            this.label2.TabIndex = 3;
            this.label2.Text = "Jerked:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(87, 282);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(14, 16);
            this.label3.TabIndex = 4;
            this.label3.Text = "0";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox1.Image = global::OLS.Properties.Resources.tony;
            this.pictureBox1.Location = new System.Drawing.Point(12, 51);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(394, 219);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // timer_counter
            // 
            this.timer_counter.AutoSize = true;
            this.timer_counter.Location = new System.Drawing.Point(392, 282);
            this.timer_counter.Name = "timer_counter";
            this.timer_counter.Size = new System.Drawing.Size(21, 16);
            this.timer_counter.TabIndex = 7;
            this.timer_counter.Text = "15";
            this.timer_counter.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // timer_label
            // 
            this.timer_label.AutoSize = true;
            this.timer_label.Location = new System.Drawing.Point(317, 282);
            this.timer_label.Name = "timer_label";
            this.timer_label.Size = new System.Drawing.Size(61, 16);
            this.timer_label.TabIndex = 6;
            this.timer_label.Text = "Time left:";
            this.timer_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(418, 502);
            this.Controls.Add(this.timer_counter);
            this.Controls.Add(this.timer_label);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.jerked_off_progress);
            this.Controls.Add(this.jerk_button);
            this.Controls.Add(this.label1);
            this.Name = "Form3";
            this.Text = "SAVE YOUR ASS!";
            this.Load += new System.EventHandler(this.Form3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button jerk_button;
        private System.Windows.Forms.ProgressBar jerked_off_progress;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label timer_counter;
        private System.Windows.Forms.Label timer_label;
    }
}