﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OLS
{
    public partial class Form2 : Form
    {
        int currentGameTime = 0; // В минутах
        int timeSpeed = 1000;
        Timer timer = new Timer();

        public Form2()
        {
            InitializeComponent();

            timer.Start();

            timer.Interval = timeSpeed;
            timer.Tick += AddTime;
           
        }

        private void AddTime(object sender, EventArgs e)
        {
            currentGameTime += 1;
            label2.Text = currentGameTime.ToString();

            if (currentGameTime == 60)
            {
                timer.Stop();
                label1.Text = "Игра окончена";
                MessageBox.Show("You survived the night!", "Congratulations", MessageBoxButtons.OK);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
